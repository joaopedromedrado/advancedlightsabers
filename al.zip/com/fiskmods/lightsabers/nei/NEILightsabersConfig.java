package com.fiskmods.lightsabers.nei;

import com.fiskmods.lightsabers.Lightsabers;

public class NEILightsabersConfig {
}
