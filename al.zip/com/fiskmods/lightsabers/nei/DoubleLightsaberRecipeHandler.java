package com.fiskmods.lightsabers.nei;

import com.fiskmods.lightsabers.client.sound.ALSounds;
import com.fiskmods.lightsabers.common.item.ItemDoubleLightsaber;
import com.fiskmods.lightsabers.common.item.ModItems;
import com.fiskmods.lightsabers.common.lightsaber.LightsaberData;

import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;

public class DoubleLightsaberRecipeHandler
{
}
