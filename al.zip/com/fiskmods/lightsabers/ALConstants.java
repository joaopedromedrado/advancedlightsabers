package com.fiskmods.lightsabers;

public interface ALConstants
{
    String BATTLEGEAR = "battlegear2";
    String DYNAMIC_LIGHTS = "DynamicLights";

    String TAG_PART = "Type";
    String TAG_POUCH_UUID = "PouchID";
    String TAG_LIGHTSABER = "Lightsaber";
    String TAG_LIGHTSABER_SPECIAL = "Special";

    int FORCE_POWER_COOLDOWN = 20;
}
