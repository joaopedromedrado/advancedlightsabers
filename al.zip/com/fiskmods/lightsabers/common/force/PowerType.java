package com.fiskmods.lightsabers.common.force;

public enum PowerType
{
    PER_USE,
    PER_SECOND,
    PASSIVE
}
