package com.fiskmods.lightsabers.common.event;

import com.fiskmods.lightsabers.common.item.ModItems;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.item.ItemStack;

public class ClientEventHandlerBG
{
}
