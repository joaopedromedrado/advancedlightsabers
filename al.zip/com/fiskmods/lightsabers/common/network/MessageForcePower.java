package com.fiskmods.lightsabers.common.network;

public class MessageForcePower
{
    
    
    public MessageForcePower()
    {
    }
    
}
